
void *randptr(void);
int randint(void);
off_t randoff(void);
size_t randsize(void);

void trycalls(int asst, int dofork, int count);
